let dayGlobalVar = [
    {
        Name: "Day One",
        Date: {
            Day_of_Week: "Wednesday",
            Month: "October",
            Numeral_Day: "13"
        },

        Weather: {
            Sky_Color: "Grey",
            Sky: "Fog",
            Morning_Temp_Celsius: "15",
            Wind: "Mild",
            Rain: "No"
        },

        Tired: "Yes",
        Cat_Mood: "Annoying",
        Assignment_Due: "Yes",
        Breakfast: "No",
        General_Mood: "Mediocre"
    }
]