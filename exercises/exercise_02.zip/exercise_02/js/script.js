$(document).ready(function() {
  $("#submit-button").click(function(event){
    $('#result-container').load('loadFiles/result.html');
   });
});

